if(localStorage.getItem('event_type')=='free'){console.log("no tickets")
document.querySelector('.ticket_type').style.display="none"
document.querySelector('.ticket_price').style.display="none"
document.querySelector('.subtotal').style.display="none"
document.querySelector('.ticket_price').style.display="none"
document.querySelector('.ticket_pricee').style.display="none"};